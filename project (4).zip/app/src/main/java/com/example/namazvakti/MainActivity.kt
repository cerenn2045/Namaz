package com.example.namazvakti

import android.Manifest
import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.time.Duration
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Locale

class MainActivity : Activity() {

    // Yeşil ve altın renk paleti
    private val ZEMIN = Color.parseColor("#0B3B2E")
    private val KART = Color.parseColor("#14543F")
    private val ALTIN = Color.parseColor("#D4AF37")
    private val KREM = Color.parseColor("#F5EFD9")
    private val SOLUK = Color.parseColor("#A9C2B5")

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val gorunenAd = listOf("Sabah", "Güneş", "Öğle", "İkindi", "Akşam", "Yatsı")
    private val gorunenAnahtar = listOf("Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha")
    private val besVakitAnahtar = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")
    private val besVakitSatir = listOf(0, 2, 3, 4, 5) // 5 vaktin, 6 satırlı listedeki yeri

    private lateinit var sehirYazi: TextView
    private lateinit var sonrakiYazi: TextView
    private lateinit var geriSayimYazi: TextView
    private lateinit var vakitlerKutusu: LinearLayout
    private lateinit var durumYazi: TextView
    private lateinit var sehirKutusu: EditText
    private lateinit var kaymaKutusu: EditText
    private lateinit var ezanKutusu: CheckBox

    private var sonGosterilen = -2
    private val handler = Handler(Looper.getMainLooper())
    private val saniye = object : Runnable {
        override fun run() {
            sayimiGuncelle()
            handler.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun arkaplan(renk: Int, yaricap: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(renk)
        g.cornerRadius = dp(yaricap).toFloat()
        return g
    }

    private fun yazi(metin: String, boyut: Float, renk: Int, kalin: Boolean = false): TextView {
        val t = TextView(this)
        t.text = metin
        t.textSize = boyut
        t.setTextColor(renk)
        if (kalin) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun kart(): LinearLayout {
        val k = LinearLayout(this)
        k.orientation = LinearLayout.VERTICAL
        k.background = arkaplan(KART, 16)
        k.setPadding(dp(16), dp(14), dp(16), dp(14))
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.setMargins(0, 0, 0, dp(12))
        k.layoutParams = lp
        return k
    }

    private fun alan(ipucu: String): EditText {
        val e = EditText(this)
        e.hint = ipucu
        e.setTextColor(KREM)
        e.setHintTextColor(SOLUK)
        e.setSingleLine()
        e.backgroundTintList = ColorStateList.valueOf(ALTIN)
        return e
    }

    private fun dugme(metin: String): Button {
        val b = Button(this)
        b.text = metin
        b.transformationMethod = null
        b.setTextColor(ZEMIN)
        b.setTypeface(b.typeface, Typeface.BOLD)
        b.background = arkaplan(ALTIN, 12)
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.setMargins(0, dp(10), 0, 0)
        b.layoutParams = lp
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = ZEMIN
        window.navigationBarColor = ZEMIN
        window.decorView.setBackgroundColor(ZEMIN)
        val ayar = getSharedPreferences("ayar", MODE_PRIVATE)

        val kok = LinearLayout(this)
        kok.orientation = LinearLayout.VERTICAL
        kok.setPadding(dp(16), dp(24), dp(16), dp(24))

        // Başlık
        val baslik = yazi("Namaz Vakti", 30f, ALTIN, true)
        baslik.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        kok.addView(baslik)
        sehirYazi = yazi(ayar.getString("sehir", "Bursa") ?: "Bursa", 15f, SOLUK)
        sehirYazi.setPadding(0, 0, 0, dp(16))
        kok.addView(sehirYazi)

        // Geri sayım kartı
        val sayimKarti = kart()
        sayimKarti.gravity = Gravity.CENTER_HORIZONTAL
        sonrakiYazi = yazi("Vakitler alınıyor...", 15f, SOLUK)
        sonrakiYazi.gravity = Gravity.CENTER_HORIZONTAL
        geriSayimYazi = yazi("--:--:--", 46f, ALTIN, true)
        geriSayimYazi.gravity = Gravity.CENTER_HORIZONTAL
        sayimKarti.addView(sonrakiYazi)
        sayimKarti.addView(geriSayimYazi)
        kok.addView(sayimKarti)

        // Vakit kartları
        vakitlerKutusu = kart()
        vakitlerKutusu.setPadding(dp(8), dp(8), dp(8), dp(8))
        kok.addView(vakitlerKutusu)

        // Günün ayeti / hadisi
        val ayetKarti = kart()
        ayetKarti.addView(yazi("Günün ayeti / hadisi", 13f, ALTIN, true))
        val ayet = yazi(Icerik.gunun(LocalDate.now().toEpochDay()), 16f, KREM)
        ayet.typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC)
        ayet.setPadding(0, dp(8), 0, 0)
        ayet.setLineSpacing(0f, 1.15f)
        ayetKarti.addView(ayet)
        kok.addView(ayetKarti)

        // Ayarlar
        val ayarKarti = kart()
        ayarKarti.addView(yazi("Ayarlar", 18f, ALTIN, true))

        sehirKutusu = alan("Şehir (örn. Bursa)")
        sehirKutusu.setText(ayar.getString("sehir", "Bursa"))
        ayarKarti.addView(sehirKutusu)

        val kaymaYazi = yazi(
            "Bildirim kaç dakika kaysın? (-10 = vakitten 10 dk önce, 0 = tam vakitte, 5 = 5 dk sonra)",
            13f, SOLUK
        )
        kaymaYazi.setPadding(0, dp(12), 0, 0)
        ayarKarti.addView(kaymaYazi)

        kaymaKutusu = alan("0")
        kaymaKutusu.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
        kaymaKutusu.setText(ayar.getInt("kayma", 0).toString())
        ayarKarti.addView(kaymaKutusu)

        ezanKutusu = CheckBox(this)
        ezanKutusu.text = "Ezan sesi kullan"
        ezanKutusu.setTextColor(KREM)
        ezanKutusu.buttonTintList = ColorStateList.valueOf(ALTIN)
        ezanKutusu.isChecked = ayar.getBoolean("ezan", true)
        ezanKutusu.isEnabled = Vakitler.ezanVarMi(this)
        ayarKarti.addView(ezanKutusu)

        ayarKarti.addView(
            yazi(
                if (Vakitler.ezanVarMi(this)) "Ezan ses dosyası bulundu."
                else "Ezan ses dosyası yok. Depoya ezan.mp3 yükleyip yeniden derletirsen eklenir.",
                13f, SOLUK
            )
        )

        val kaydet = dugme("Kaydet ve alarmları kur")
        kaydet.setOnClickListener { kur() }
        ayarKarti.addView(kaydet)

        val deneme = dugme("Deneme bildirimi gönder")
        deneme.setOnClickListener {
            Vakitler.bildir(this, 0, LocalDate.now().toEpochDay())
        }
        ayarKarti.addView(deneme)

        durumYazi = yazi("", 14f, KREM)
        durumYazi.setPadding(0, dp(12), 0, 0)
        ayarKarti.addView(durumYazi)
        kok.addView(ayarKarti)

        val not = yazi(
            "Bildirimler gecikirse Ayarlar > Uygulamalar > Namaz Vakti > Pil bölümünden " +
                "\"Kısıtlanmamış\" seçeneğini işaretle. Titreşimi veya sesi telefonun bildirim " +
                "ayarlarından (Namaz vakti kanalı) da değiştirebilirsin.",
            12f, SOLUK
        )
        kok.addView(not)

        val kaydirma = ScrollView(this)
        kaydirma.setBackgroundColor(ZEMIN)
        kaydirma.addView(kok)
        setContentView(kaydirma)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        kartlariCiz()
        kur()
    }

    override fun onResume() {
        super.onResume()
        handler.post(saniye)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(saniye)
    }

    // Sıradaki vakti bulur: (vakit no, zaman, yarın mı)
    private fun sonrakiBul(): Triple<Int, ZonedDateTime, Boolean>? {
        val ayar = getSharedPreferences("ayar", MODE_PRIVATE)
        val bolge = try {
            ZoneId.of(ayar.getString("bolge", "Europe/Istanbul") ?: "Europe/Istanbul")
        } catch (e: Exception) {
            ZoneId.of("Europe/Istanbul")
        }
        val simdi = ZonedDateTime.now(bolge)
        val bugun = simdi.toLocalDate()
        for (d in 0..1) {
            val gun = bugun.plusDays(d.toLong())
            val saatler = Vakitler.gunVerisi(this, gun) ?: continue
            for (j in 0..4) {
                val saat = saatler[besVakitAnahtar[j]] ?: continue
                val t = ZonedDateTime.of(gun, saat, bolge)
                if (t.isAfter(simdi)) return Triple(j, t, d == 1)
            }
        }
        return null
    }

    private fun sayimiGuncelle() {
        val sonraki = sonrakiBul()
        if (sonraki == null) {
            sonrakiYazi.text = "Vakitler alınıyor..."
            geriSayimYazi.text = "--:--:--"
            return
        }
        val (j, zaman, yarin) = sonraki
        val kalan = Duration.between(ZonedDateTime.now(zaman.zone), zaman)
        val sn = kalan.seconds.coerceAtLeast(0L)
        geriSayimYazi.text = String.format(Locale.US, "%02d:%02d:%02d", sn / 3600, (sn % 3600) / 60, sn % 60)
        sonrakiYazi.text = (if (yarin) "Yarın " else "") +
            "${Vakitler.adlar[j]} vaktine kalan süre (${zaman.toLocalTime().toString().take(5)})"
        if (besVakitSatir[j] != sonGosterilen) kartlariCiz()
    }

    private fun kartlariCiz() {
        vakitlerKutusu.removeAllViews()
        val saatler = Vakitler.gunVerisi(this, LocalDate.now())
        val sonraki = sonrakiBul()
        val vurgu = if (sonraki != null) besVakitSatir[sonraki.first] else -1
        for (i in 0..5) {
            val secili = i == vurgu
            val renk = if (secili) ZEMIN else if (i == 1) SOLUK else KREM

            val satir = LinearLayout(this)
            satir.orientation = LinearLayout.HORIZONTAL
            satir.gravity = Gravity.CENTER_VERTICAL
            satir.setPadding(dp(14), dp(12), dp(14), dp(12))
            if (secili) satir.background = arkaplan(ALTIN, 12)
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.setMargins(0, 0, 0, dp(4))
            satir.layoutParams = lp

            val ad = yazi(gorunenAd[i], 18f, renk, secili)
            ad.layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
            val saatMetni = saatler?.get(gorunenAnahtar[i])?.toString()?.take(5) ?: "--:--"
            val saat = yazi(saatMetni, 20f, renk, true)

            satir.addView(ad)
            satir.addView(saat)
            vakitlerKutusu.addView(satir)
        }
        sonGosterilen = vurgu
    }

    private fun kur() {
        val sehir = sehirKutusu.text.toString().trim().ifEmpty { "Bursa" }
        val kayma = (kaymaKutusu.text.toString().trim().toIntOrNull() ?: 0).coerceIn(-120, 120)
        getSharedPreferences("ayar", MODE_PRIVATE).edit()
            .putString("sehir", sehir)
            .putInt("kayma", kayma)
            .putBoolean("ezan", ezanKutusu.isChecked)
            .apply()
        sehirYazi.text = sehir
        kaymaKutusu.setText(kayma.toString())
        durumYazi.text = "Vakitler alınıyor..."
        Thread {
            val mesaj = try {
                Vakitler.planla(applicationContext)
                "Alarmlar kuruldu." +
                    (if (kayma < 0) "\nBildirimler vakitten ${-kayma} dk önce gelir."
                    else if (kayma > 0) "\nBildirimler vakitten $kayma dk sonra gelir." else "")
            } catch (e: Exception) {
                "Hata: ${e.message}\nİnternet bağlantını ve şehir adını kontrol et."
            }
            runOnUiThread {
                durumYazi.text = mesaj
                kartlariCiz()
                sayimiGuncelle()
            }
        }.start()
    }
}
