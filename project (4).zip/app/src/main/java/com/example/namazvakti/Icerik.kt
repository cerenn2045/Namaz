package com.example.namazvakti

// Ayet ve hadislerin anlamları özetle verilmiştir.
// Buraya istediğin satırları ekleyip çıkarabilirsin.
object Icerik {

    private val genel = listOf(
        "Namaz, müminlere belirli vakitlerde farz kılınmıştır. (Nisâ, 103)",
        "Şüphesiz namaz, insanı hayasızlıktan ve kötülükten alıkoyar. (Ankebût, 45)",
        "Beni anmak için namaz kıl. (Tâhâ, 14)",
        "Sabır ve namazla yardım dileyin. Allah sabredenlerle beraberdir. (Bakara, 153)",
        "Namazlarında huşu içinde olan müminler gerçekten kurtuluşa ermiştir. (Mü'minûn, 1-2)",
        "Namazlarını titizlikle koruyanlar da kurtuluşa erenlerdir. (Mü'minûn, 9)",
        "Ailene namazı emret, kendin de ona devam et. (Tâhâ, 132)",
        "Müttakiler gaybe inanır, namazı dosdoğru kılar ve verdiğimiz rızıktan harcarlar. (Bakara, 3)",
        "Gündüzün iki ucunda ve gecenin ilk saatlerinde namaz kıl. Çünkü iyilikler kötülükleri giderir. (Hûd, 114)",
        "Namazı kılın, zekâtı verin ve Peygamber'e itaat edin ki merhamet edilesiniz. (Nûr, 56)",
        "Güneş doğmadan önce ve batmadan önce Rabbini hamd ile tesbih et. (Tâhâ, 130)",
        "Kapısının önünde bir nehir akan kimse her gün beş kez yıkansa kirinden bir şey kalır mı? İşte beş vakit namaz da böyledir; Allah onunla hataları siler. (Buhârî, Mevâkît 6; Müslim, Mesâcid 283)",
        "Kıyamet günü kulun ilk hesaba çekileceği amel namazdır. (Tirmizî, Salât 188)",
        "Peygamberimize \"Hangi amel daha sevimlidir?\" diye sorulunca \"Vaktinde kılınan namaz\" buyurdu. (Buhârî, Mevâkît 5)",
        "Cemaatle kılınan namaz, tek başına kılınan namazdan yirmi yedi derece üstündür. (Buhârî, Ezan 30; Müslim, Mesâcid 249)",
        "Ezan ile kamet arasında yapılan dua geri çevrilmez. (Ebû Dâvûd; Tirmizî)"
    )

    private val ozel: Map<Int, List<String>> = mapOf(
        0 to listOf(
            "Sabah namazını kılan kimse Allah'ın korumasındadır. (Müslim, Mesâcid 261)",
            "Serinlik vaktinin iki namazını (sabah ve ikindi) kılan cennete girer. (Buhârî, Mevâkît 26)",
            "Güneşin kaymasından gecenin kararmasına kadar namaz kıl, sabah namazını da. Çünkü sabah namazına şahitlik edilir. (İsrâ, 78)",
            "Kim sabah namazını cemaatle kılarsa bütün geceyi ibadetle geçirmiş gibi olur. (Müslim, Mesâcid 260)"
        ),
        2 to listOf(
            "Namazları, özellikle orta namazı (ikindi) koruyun. (Bakara, 238)",
            "Serinlik vaktinin iki namazını (sabah ve ikindi) kılan cennete girer. (Buhârî, Mevâkît 26)",
            "İkindi namazını kaçıran kimse, ailesini ve malını kaybetmiş gibidir. (Buhârî, Mevâkît 14; Müslim, Mesâcid 200)"
        ),
        4 to listOf(
            "Kim yatsı namazını cemaatle kılarsa gecenin yarısını ibadetle geçirmiş gibi olur. (Müslim, Mesâcid 260)"
        )
    )

    // Ana ekrandaki "günün ayeti/hadisi"
    fun gunun(gun: Long): String =
        genel[Math.floorMod(gun, genel.size.toLong()).toInt()]

    fun sec(j: Int, gun: Long): String {
        val havuz = genel + (ozel[j] ?: emptyList())
        val i = Math.floorMod(gun * 5 + j, havuz.size.toLong()).toInt()
        return havuz[i]
    }
}
