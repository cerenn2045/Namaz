plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Depo ana klasörüne yüklediğin ezan.mp3 (veya .ogg/.wav/.m4a) uygulamaya otomatik eklenir.
for (uzanti in listOf("mp3", "ogg", "wav", "m4a")) {
    val kaynak = rootProject.file("../ezan.$uzanti")
    if (kaynak.exists()) {
        val hedef = file("src/main/res/raw")
        hedef.mkdirs()
        kaynak.copyTo(File(hedef, "ezan.$uzanti"), overwrite = true)
        break
    }
}

android {
    namespace = "com.example.namazvakti"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.namazvakti"
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "4.0"
    }

    // Sabit imza: sonraki sürümler eskisinin üzerine kurulabilsin diye.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
}
