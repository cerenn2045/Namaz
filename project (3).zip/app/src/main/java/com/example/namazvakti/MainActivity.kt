package com.example.namazvakti

import android.Manifest
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.time.LocalDate

class MainActivity : Activity() {

    private lateinit var sehirKutusu: EditText
    private lateinit var kaymaKutusu: EditText
    private lateinit var ezanKutusu: CheckBox
    private lateinit var bilgi: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ayar = getSharedPreferences("ayar", MODE_PRIVATE)
        val bosluk = (20 * resources.displayMetrics.density).toInt()

        val kok = LinearLayout(this)
        kok.orientation = LinearLayout.VERTICAL
        kok.setPadding(bosluk, bosluk * 2, bosluk, bosluk)

        val baslik = TextView(this)
        baslik.text = "Namaz Vakti Hatırlatıcı"
        baslik.textSize = 22f
        kok.addView(baslik)

        sehirKutusu = EditText(this)
        sehirKutusu.hint = "Şehir (örn. Bursa)"
        sehirKutusu.setText(ayar.getString("sehir", "Bursa"))
        sehirKutusu.setSingleLine()
        kok.addView(sehirKutusu)

        val kaymaYazi = TextView(this)
        kaymaYazi.text = "\nBildirim kaç dakika kaysın? (-10 = vakitten 10 dk önce, 0 = tam vakitte, 5 = 5 dk sonra)"
        kok.addView(kaymaYazi)

        kaymaKutusu = EditText(this)
        kaymaKutusu.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
        kaymaKutusu.setText(ayar.getInt("kayma", 0).toString())
        kaymaKutusu.setSingleLine()
        kok.addView(kaymaKutusu)

        ezanKutusu = CheckBox(this)
        ezanKutusu.text = "Ezan sesi kullan"
        ezanKutusu.isChecked = ayar.getBoolean("ezan", true)
        ezanKutusu.isEnabled = Vakitler.ezanVarMi(this)
        kok.addView(ezanKutusu)

        val ezanDurum = TextView(this)
        ezanDurum.text = if (Vakitler.ezanVarMi(this)) "Ezan ses dosyası bulundu."
        else "Ezan ses dosyası yok. Depoya ezan.mp3 yükleyip yeniden derletirsen eklenir."
        kok.addView(ezanDurum)

        val kaydet = Button(this)
        kaydet.text = "Kaydet ve alarmları kur"
        kaydet.setOnClickListener { kur() }
        kok.addView(kaydet)

        val deneme = Button(this)
        deneme.text = "Deneme bildirimi gönder"
        deneme.setOnClickListener {
            Vakitler.bildir(this, 0, LocalDate.now().toEpochDay())
        }
        kok.addView(deneme)

        bilgi = TextView(this)
        bilgi.textSize = 16f
        bilgi.setPadding(0, bosluk, 0, 0)
        kok.addView(bilgi)

        val not = TextView(this)
        not.text = "\nNot: Bildirimler gecikirse Ayarlar > Uygulamalar > Namaz Vakti > Pil bölümünden " +
            "\"Kısıtlanmamış\" seçeneğini işaretle. Titreşimi veya sesi telefonun bildirim ayarlarından " +
            "(Namaz vakti kanalı) da değiştirebilirsin."
        kok.addView(not)

        val kaydirma = ScrollView(this)
        kaydirma.addView(kok)
        setContentView(kaydirma)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        kur()
    }

    private fun kur() {
        val sehir = sehirKutusu.text.toString().trim().ifEmpty { "Bursa" }
        val kayma = (kaymaKutusu.text.toString().trim().toIntOrNull() ?: 0).coerceIn(-120, 120)
        getSharedPreferences("ayar", MODE_PRIVATE).edit()
            .putString("sehir", sehir)
            .putInt("kayma", kayma)
            .putBoolean("ezan", ezanKutusu.isChecked)
            .apply()
        kaymaKutusu.setText(kayma.toString())
        bilgi.text = "Vakitler alınıyor..."
        Thread {
            val mesaj = try {
                Vakitler.planla(applicationContext)
            } catch (e: Exception) {
                "Hata: ${e.message}\nİnternet bağlantını ve şehir adını kontrol et."
            }
            runOnUiThread { bilgi.text = mesaj }
        }.start()
    }
}
