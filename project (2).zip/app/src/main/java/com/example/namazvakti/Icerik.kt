package com.example.namazvakti

// Ayet ve hadislerin anlamları özetle verilmiştir.
// Buraya istediğin satırları ekleyip çıkarabilirsin.
object Icerik {

    private val genel = listOf(
        "Namaz, müminlere belirli vakitlerde farz kılınmıştır. (Nisâ, 103)",
        "Şüphesiz namaz, insanı hayasızlıktan ve kötülükten alıkoyar. (Ankebût, 45)",
        "Beni anmak için namaz kıl. (Tâhâ, 14)",
        "Sabır ve namazla yardım dileyin. (Bakara, 45)",
        "Namazlarında huşu içinde olan müminler gerçekten kurtuluşa ermiştir. (Mü'minûn, 1-2)",
        "Ailene namazı emret, kendin de ona devam et. (Tâhâ, 132)",
        "Kapısının önünde bir nehir akan kimse her gün beş kez yıkansa kirinden bir şey kalır mı? İşte beş vakit namaz da böyledir; Allah onunla hataları siler. (Buhârî, Mevâkît 6; Müslim, Mesâcid 283)",
        "Kıyamet günü kulun ilk hesaba çekileceği amel namazdır. (Tirmizî, Salât 188)",
        "Peygamberimize \"Hangi amel daha sevimlidir?\" diye sorulunca \"Vaktinde kılınan namaz\" buyurdu. (Buhârî, Mevâkît 5)"
    )

    private val ozel: Map<Int, List<String>> = mapOf(
        0 to listOf(
            "Sabah namazını kılan kimse Allah'ın korumasındadır. (Müslim, Mesâcid 261)",
            "Serinlik vaktinin iki namazını (sabah ve ikindi) kılan cennete girer. (Buhârî, Mevâkît 26)"
        ),
        2 to listOf(
            "Namazları, özellikle orta namazı (ikindi) koruyun. (Bakara, 238)",
            "Serinlik vaktinin iki namazını (sabah ve ikindi) kılan cennete girer. (Buhârî, Mevâkît 26)"
        )
    )

    fun sec(j: Int, gun: Long): String {
        val havuz = genel + (ozel[j] ?: emptyList())
        val i = Math.floorMod(gun * 5 + j, havuz.size.toLong()).toInt()
        return havuz[i]
    }
}
