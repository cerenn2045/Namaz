package com.example.namazvakti

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val j = intent.getIntExtra("j", 0)
        val gun = intent.getLongExtra("gun", 0L)
        Vakitler.bildir(ctx, j, gun)

        // Bildirimden sonra ilerideki günlerin alarmlarını tazele.
        val sonuc = goAsync()
        Thread {
            try {
                Vakitler.planla(ctx.applicationContext)
            } catch (e: Exception) {
                // İnternet yoksa mevcut alarmlar çalışmaya devam eder.
            } finally {
                sonuc.finish()
            }
        }.start()
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val sonuc = goAsync()
        Thread {
            try {
                Vakitler.planla(ctx.applicationContext)
            } catch (e: Exception) {
            } finally {
                sonuc.finish()
            }
        }.start()
    }
}
