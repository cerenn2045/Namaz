package com.example.namazvakti

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

object Vakitler {

    val adlar = listOf("Sabah", "Öğle", "İkindi", "Akşam", "Yatsı")
    private val anahtarlar = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")
    private const val KANAL = "vakit_kanali"

    // Aladhan API, yöntem 13 = Diyanet İşleri Başkanlığı
    private fun gunuGetir(sehir: String, gun: LocalDate): Pair<ZoneId, Map<String, LocalTime>> {
        val tarih = gun.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"))
        val adres = "https://api.aladhan.com/v1/timingsByCity/$tarih" +
            "?city=${URLEncoder.encode(sehir, "UTF-8")}&country=Turkey&method=13"
        val baglanti = URL(adres).openConnection() as HttpURLConnection
        baglanti.connectTimeout = 8000
        baglanti.readTimeout = 8000
        val metin = baglanti.inputStream.bufferedReader().use { it.readText() }
        baglanti.disconnect()

        val veri = JSONObject(metin).getJSONObject("data")
        val zamanlar = veri.getJSONObject("timings")
        val bolge = ZoneId.of(veri.getJSONObject("meta").getString("timezone"))
        val sonuc = LinkedHashMap<String, LocalTime>()
        for (k in listOf("Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha")) {
            sonuc[k] = LocalTime.parse(zamanlar.getString(k).substring(0, 5))
        }
        return Pair(bolge, sonuc)
    }

    // Önümüzdeki 3 günün vakitlerini alıp alarmları kurar. Arka plan thread'inde çağır.
    fun planla(ctx: Context): String {
        val ayar = ctx.getSharedPreferences("ayar", Context.MODE_PRIVATE)
        val sehir = ayar.getString("sehir", "Bursa") ?: "Bursa"
        val alarmYonetici = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val simdi = System.currentTimeMillis()
        val baslangic = LocalDate.now()
        var ozet = ""

        for (i in 0..2) {
            val gun = baslangic.plusDays(i.toLong())
            try {
                val (bolge, saatler) = gunuGetir(sehir, gun)
                for (j in 0..4) {
                    val saat = saatler[anahtarlar[j]]!!
                    val ms = ZonedDateTime.of(gun, saat, bolge).toInstant().toEpochMilli()
                    if (ms > simdi) alarmKur(ctx, alarmYonetici, gun, j, ms)
                }
                if (i == 0) {
                    ozet = "$sehir için bugünün vakitleri (Diyanet):\n\n" +
                        "Sabah:  ${saatler["Fajr"]}\n" +
                        "Güneş:  ${saatler["Sunrise"]}\n" +
                        "Öğle:   ${saatler["Dhuhr"]}\n" +
                        "İkindi: ${saatler["Asr"]}\n" +
                        "Akşam:  ${saatler["Maghrib"]}\n" +
                        "Yatsı:  ${saatler["Isha"]}\n\n" +
                        "Alarmlar kuruldu."
                }
            } catch (e: Exception) {
                if (i == 0) throw e
            }
        }
        ayar.edit().putString("ozet", ozet).apply()
        return ozet
    }

    private fun alarmKur(ctx: Context, am: AlarmManager, gun: LocalDate, j: Int, ms: Long) {
        val niyet = Intent(ctx, AlarmReceiver::class.java)
        niyet.putExtra("j", j)
        niyet.putExtra("gun", gun.toEpochDay())
        // Aynı gün+vakit her zaman aynı kodu alır, böylece çift alarm oluşmaz.
        val kod = (gun.toEpochDay() % 100000).toInt() * 10 + j
        val pi = PendingIntent.getBroadcast(
            ctx, kod, niyet, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
        }
    }

    fun bildir(ctx: Context, j: Int, gun: Long) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(KANAL, "Namaz vakitleri", NotificationManager.IMPORTANCE_HIGH)
        )
        val icerik = Icerik.sec(j, gun)
        val dokun = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val bildirim = NotificationCompat.Builder(ctx, KANAL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("${adlar[j]} namazı vakti")
            .setContentText(icerik)
            .setStyle(NotificationCompat.BigTextStyle().bigText(icerik))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(dokun)
            .setAutoCancel(true)
            .build()
        nm.notify(200 + j, bildirim)
    }
}
