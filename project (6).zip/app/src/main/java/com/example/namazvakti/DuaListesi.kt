package com.example.namazvakti

class Dua(
    val grup: String,
    val baslik: String,
    val arapca: String,
    val okunus: String,
    val anlam: String
)

// Anlamlar özet niteliğindedir. Arapça metinleri güvenilir bir kaynakla karşılaştırarak kullan.
object DuaListesi {
    val liste = listOf(
        Dua(
            "Namazda okunanlar", "Sübhâneke",
            "سُبْحَانَكَ اللَّهُمَّ وَبِحَمْدِكَ وَتَبَارَكَ اسْمُكَ وَتَعَالَىٰ جَدُّكَ وَلَا إِلَٰهَ غَيْرُكَ",
            "Sübhânekellâhümme ve bihamdik, ve tebârekesmük, ve teâlâ ceddük, ve lâ ilâhe gayruk.",
            "Allah'ım! Seni her türlü eksiklikten uzak tutarım, sana hamd ederim. Senin adın mübarektir, şanın yücedir. Senden başka ilah yoktur."
        ),
        Dua(
            "Namazda okunanlar", "Fâtiha Sûresi",
            "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ ﴿١﴾ الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ ﴿٢﴾ الرَّحْمَٰنِ الرَّحِيمِ ﴿٣﴾ مَالِكِ يَوْمِ الدِّينِ ﴿٤﴾ إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ ﴿٥﴾ اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ ﴿٦﴾ صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ ﴿٧﴾",
            "Bismillâhirrahmânirrahîm. Elhamdü lillâhi rabbil'âlemîn. Errahmânirrahîm. Mâliki yevmiddîn. İyyâke na'büdü ve iyyâke neste'în. İhdinessırâtal müstakîm. Sırâtallezîne en'amte aleyhim gayril mağdûbi aleyhim ve leddâllîn.",
            "Rahman ve Rahim olan Allah'ın adıyla. Hamd, âlemlerin Rabbi Allah'adır. O, Rahman ve Rahim'dir; din gününün sahibidir. Yalnız sana kulluk eder, yalnız senden yardım dileriz. Bizi doğru yola ilet; kendilerine nimet verdiklerinin yoluna; gazaba uğrayanların ve sapıtanların yoluna değil."
        ),
        Dua(
            "Namazda okunanlar", "İhlâs Sûresi",
            "قُلْ هُوَ اللَّهُ أَحَدٌ ﴿١﴾ اللَّهُ الصَّمَدُ ﴿٢﴾ لَمْ يَلِدْ وَلَمْ يُولَدْ ﴿٣﴾ وَلَمْ يَكُنْ لَهُ كُفُوًا أَحَدٌ ﴿٤﴾",
            "Kul hüvallâhü ehad. Allâhüssamed. Lem yelid ve lem yûled. Ve lem yekün lehû küfüven ehad.",
            "De ki: O, Allah'tır, tektir. Allah sameddir (hiçbir şeye muhtaç değildir, her şey O'na muhtaçtır). O doğurmamış ve doğurulmamıştır. Hiçbir şey O'na denk değildir."
        ),
        Dua(
            "Namazda okunanlar", "Felak Sûresi",
            "قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ ﴿١﴾ مِنْ شَرِّ مَا خَلَقَ ﴿٢﴾ وَمِنْ شَرِّ غَاسِقٍ إِذَا وَقَبَ ﴿٣﴾ وَمِنْ شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ ﴿٤﴾ وَمِنْ شَرِّ حَاسِدٍ إِذَا حَسَدَ ﴿٥﴾",
            "Kul eûzü bi rabbil felak. Min şerri mâ halak. Ve min şerri gâsikın izâ vekab. Ve min şerrin neffâsâti fil ukad. Ve min şerri hâsidin izâ hased.",
            "De ki: Sabahın Rabbine sığınırım; yarattığı şeylerin şerrinden, karanlığı çöktüğünde gecenin şerrinden, düğümlere üfleyenlerin şerrinden ve haset ettiğinde hasetçinin şerrinden."
        ),
        Dua(
            "Namazda okunanlar", "Nâs Sûresi",
            "قُلْ أَعُوذُ بِرَبِّ النَّاسِ ﴿١﴾ مَلِكِ النَّاسِ ﴿٢﴾ إِلَٰهِ النَّاسِ ﴿٣﴾ مِنْ شَرِّ الْوَسْوَاسِ الْخَنَّاسِ ﴿٤﴾ الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ ﴿٥﴾ مِنَ الْجِنَّةِ وَالنَّاسِ ﴿٦﴾",
            "Kul eûzü bi rabbin nâs. Melikin nâs. İlâhin nâs. Min şerril vesvâsil hannâs. Ellezî yüvesvisü fî sudûrin nâs. Minel cinneti ven nâs.",
            "De ki: İnsanların Rabbine, insanların Melik'ine, insanların İlâh'ına sığınırım; sinsi vesvesecinin şerrinden. O, insanların kalplerine vesvese verir; cinlerden de insanlardan da."
        ),
        Dua(
            "Namazda okunanlar", "Kevser Sûresi",
            "إِنَّا أَعْطَيْنَاكَ الْكَوْثَرَ ﴿١﴾ فَصَلِّ لِرَبِّكَ وَانْحَرْ ﴿٢﴾ إِنَّ شَانِئَكَ هُوَ الْأَبْتَرُ ﴿٣﴾",
            "İnnâ a'taynâkel kevser. Fesalli li rabbike venhar. İnne şânieke hüvel ebter.",
            "Şüphesiz sana Kevser'i verdik. O hâlde Rabbin için namaz kıl ve kurban kes. Asıl soyu kesik olan, sana kin besleyendir."
        ),
        Dua(
            "Namazda okunanlar", "Ettehiyyâtü",
            "التَّحِيَّاتُ لِلَّهِ وَالصَّلَوَاتُ وَالطَّيِّبَاتُ، السَّلَامُ عَلَيْكَ أَيُّهَا النَّبِيُّ وَرَحْمَةُ اللَّهِ وَبَرَكَاتُهُ، السَّلَامُ عَلَيْنَا وَعَلَىٰ عِبَادِ اللَّهِ الصَّالِحِينَ، أَشْهَدُ أَنْ لَا إِلَٰهَ إِلَّا اللَّهُ وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ",
            "Ettehiyyâtü lillâhi vessalevâtü vettayyibât. Esselâmü aleyke eyyühen nebiyyü ve rahmetullâhi ve berekâtüh. Esselâmü aleynâ ve alâ ibâdillâhis sâlihîn. Eşhedü en lâ ilâhe illallâh ve eşhedü enne Muhammeden abdühû ve resûlüh.",
            "Dil, beden ve mal ile yapılan bütün ibadetler Allah'a mahsustur. Ey Peygamber! Selam, Allah'ın rahmeti ve bereketi senin üzerine olsun. Selam bizim üzerimize ve Allah'ın salih kulları üzerine olsun. Şahitlik ederim ki Allah'tan başka ilah yoktur; yine şahitlik ederim ki Muhammed O'nun kulu ve elçisidir."
        ),
        Dua(
            "Namazda okunanlar", "Allâhümme salli",
            "اللَّهُمَّ صَلِّ عَلَىٰ مُحَمَّدٍ وَعَلَىٰ آلِ مُحَمَّدٍ كَمَا صَلَّيْتَ عَلَىٰ إِبْرَاهِيمَ وَعَلَىٰ آلِ إِبْرَاهِيمَ إِنَّكَ حَمِيدٌ مَجِيدٌ",
            "Allâhümme salli alâ Muhammedin ve alâ âli Muhammed, kemâ sallayte alâ İbrâhîme ve alâ âli İbrâhîm, inneke hamîdün mecîd.",
            "Allah'ım! İbrahim'e ve ailesine rahmet ettiğin gibi, Muhammed'e ve ailesine de rahmet et. Şüphesiz sen övülmeye layıksın, yücesin."
        ),
        Dua(
            "Namazda okunanlar", "Allâhümme bârik",
            "اللَّهُمَّ بَارِكْ عَلَىٰ مُحَمَّدٍ وَعَلَىٰ آلِ مُحَمَّدٍ كَمَا بَارَكْتَ عَلَىٰ إِبْرَاهِيمَ وَعَلَىٰ آلِ إِبْرَاهِيمَ إِنَّكَ حَمِيدٌ مَجِيدٌ",
            "Allâhümme bârik alâ Muhammedin ve alâ âli Muhammed, kemâ bârekte alâ İbrâhîme ve alâ âli İbrâhîm, inneke hamîdün mecîd.",
            "Allah'ım! İbrahim'e ve ailesine bereket verdiğin gibi, Muhammed'e ve ailesine de bereket ver. Şüphesiz sen övülmeye layıksın, yücesin."
        ),
        Dua(
            "Namazda okunanlar", "Rabbenâ âtinâ",
            "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ",
            "Rabbenâ âtinâ fid dünyâ haseneten ve fil âhirati haseneten ve kınâ azâben nâr.",
            "Rabbimiz! Bize dünyada da iyilik ver, ahirette de iyilik ver ve bizi ateş azabından koru. (Bakara, 201)"
        ),
        Dua(
            "Namazda okunanlar", "Rabbenağfir lî",
            "رَبَّنَا اغْفِرْ لِي وَلِوَالِدَيَّ وَلِلْمُؤْمِنِينَ يَوْمَ يَقُومُ الْحِسَابُ",
            "Rabbenağfir lî ve li vâlideyye ve lil mü'minîne yevme yekûmül hısâb.",
            "Rabbimiz! Hesap görülecek günde beni, annemi babamı ve bütün müminleri bağışla. (İbrâhîm, 41)"
        ),
        Dua(
            "Namazda okunanlar", "Kunut duaları (vitir namazı)",
            "اللَّهُمَّ إِنَّا نَسْتَعِينُكَ وَنَسْتَغْفِرُكَ وَنُؤْمِنُ بِكَ وَنَتُوبُ إِلَيْكَ وَنَتَوَكَّلُ عَلَيْكَ وَنُثْنِي عَلَيْكَ الْخَيْرَ وَنَشْكُرُكَ وَلَا نَكْفُرُكَ وَنَخْلَعُ وَنَتْرُكُ مَنْ يَفْجُرُكَ\nاللَّهُمَّ إِيَّاكَ نَعْبُدُ وَلَكَ نُصَلِّي وَنَسْجُدُ وَإِلَيْكَ نَسْعَىٰ وَنَحْفِدُ وَنَرْجُو رَحْمَتَكَ وَنَخْشَىٰ عَذَابَكَ إِنَّ عَذَابَكَ بِالْكُفَّارِ مُلْحِقٌ",
            "Allâhümme innâ neste'înüke ve nestağfirük ve nü'minü bike ve netûbü ileyke ve netevekkelü aleyk, ve nüsnî aleykel hayr, ve neşkürüke ve lâ nekfürük, ve nahleu ve netrükü men yefcürük.\nAllâhümme iyyâke na'büdü ve leke nusallî ve nescüdü ve ileyke nes'â ve nahfidü, ve nercû rahmeteke ve nahşâ azâbek, inne azâbeke bil küffâri mülhık.",
            "Allah'ım! Senden yardım dileriz, bağışlanma isteriz, sana inanır, sana tövbe eder, sana dayanır ve bütün hayırlarla seni överiz. Sana şükreder, nankörlük etmeyiz. Sana isyan edenlerden uzaklaşır, onları terk ederiz. Allah'ım! Yalnız sana kulluk ederiz, sana namaz kılar ve secde ederiz. Sana koşar, sana yönelir, rahmetini umar, azabından korkarız. Şüphesiz senin azabın kâfirlere ulaşacaktır."
        ),
        Dua(
            "Namaz sonrası", "Âyetel Kürsî",
            "اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۗ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ",
            "Allâhü lâ ilâhe illâ hüvel hayyül kayyûm. Lâ te'huzühû sinetün ve lâ nevm. Lehû mâ fîs semâvâti ve mâ fîl ard. Men zellezî yeşfeu indehû illâ bi iznih. Ya'lemü mâ beyne eydîhim ve mâ halfehüm. Ve lâ yühîtûne bi şey'in min ilmihî illâ bimâ şâe. Vesia kürsiyyühüs semâvâti vel ard. Ve lâ yeûdühû hıfzuhümâ. Ve hüvel aliyyül azîm.",
            "Allah, kendisinden başka ilah olmayandır; diridir, her şeyi ayakta tutandır. O'nu ne uyuklama ne de uyku tutar. Göklerde ve yerde ne varsa O'nundur. İzni olmadan O'nun katında kim şefaat edebilir? Onların önlerinde ve arkalarında olanı bilir. Dilediği kadarından başka O'nun ilminden hiçbir şeyi kavrayamazlar. Kürsüsü gökleri ve yeri kuşatmıştır; onları korumak O'na ağır gelmez. O yücedir, büyüktür. (Bakara, 255)"
        ),
        Dua(
            "Namaz sonrası", "Tesbihat",
            "سُبْحَانَ اللَّهِ  •  الْحَمْدُ لِلَّهِ  •  اللَّهُ أَكْبَرُ",
            "Sübhânallâh (33), Elhamdülillâh (33), Allâhü ekber (33). Ardından tamamlama duası okunur. Sayaç için ana ekrandaki Tesbih bölümünü kullanabilirsin.",
            "Farz namazların ardından 33'er kez tesbih, hamd ve tekbir getirilmesi hadislerde tavsiye edilmiştir."
        )
    )
}
