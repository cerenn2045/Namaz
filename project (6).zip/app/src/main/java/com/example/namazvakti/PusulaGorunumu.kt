package com.example.namazvakti

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View

// Kıble pusulası: kadran gerçek yönlere göre döner, altın Kâbe işareti kıbleyi gösterir.
class PusulaGorunumu(ctx: Context) : View(ctx) {

    var kibleAcisi = 0f   // Kâbe yönü (gerçek kuzeye göre, derece)
    var yon = 0f          // Telefonun baktığı yön (gerçek kuzeye göre, derece)
    var hazir = false

    private val altin = Color.parseColor("#D4AF37")
    private val krem = Color.parseColor("#F5EFD9")
    private val soluk = Color.parseColor("#A9C2B5")
    private val koyu = Color.parseColor("#0B3B2E")
    private val kadranRengi = Color.parseColor("#0F4A38")

    private val halka = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val dolgu = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val yazi = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }

    override fun onMeasure(genislikSpec: Int, yukseklikSpec: Int) {
        val en = MeasureSpec.getSize(genislikSpec)
        val enFazla = (260 * resources.displayMetrics.density).toInt()
        val boy = if (en <= 0) enFazla else minOf(en, enFazla)
        setMeasuredDimension(boy, boy)
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val d = resources.displayMetrics.density
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(cx, cy) - 14f * d

        // Kıbleye dönük mü? (5 dereceden az fark)
        val fark = Math.abs(((kibleAcisi - yon + 540f) % 360f) - 180f)
        val hizali = hazir && fark < 5f

        dolgu.color = kadranRengi
        c.drawCircle(cx, cy, r, dolgu)

        // Dönen kadran
        c.save()
        c.rotate(-yon, cx, cy)

        halka.color = soluk
        halka.strokeWidth = 1.5f * d
        for (i in 0 until 12) {
            c.save()
            c.rotate(i * 30f, cx, cy)
            val boyu = if (i % 3 == 0) 14f else 8f
            c.drawLine(cx, cy - r, cx, cy - r + boyu * d, halka)
            c.restore()
        }

        // Yön harfleri: K (kuzey), D (doğu), G (güney), B (batı)
        yazi.textSize = 15f * d
        val harfler = listOf("K", "D", "G", "B")
        for (i in 0 until 4) {
            c.save()
            c.rotate(i * 90f, cx, cy)
            yazi.color = if (i == 0) altin else krem
            c.drawText(harfler[i], cx, cy - r + 36f * d, yazi)
            c.restore()
        }

        // Kâbe iğnesi ve işareti
        if (hazir) {
            c.save()
            c.rotate(kibleAcisi, cx, cy)
            halka.color = altin
            halka.strokeWidth = 3f * d
            c.drawLine(cx, cy, cx, cy - r + 50f * d, halka)
            dolgu.color = altin
            val kabe = RectF(cx - 11f * d, cy - r + 14f * d, cx + 11f * d, cy - r + 48f * d)
            c.drawRoundRect(kabe, 4f * d, 4f * d, dolgu)
            dolgu.color = koyu
            c.drawRect(cx - 11f * d, cy - r + 22f * d, cx + 11f * d, cy - r + 27f * d, dolgu)
            c.restore()
        }
        c.restore()

        // Dış halka (hizalıyken altın ve kalın)
        halka.color = if (hizali) altin else soluk
        halka.strokeWidth = (if (hizali) 4f else 2f) * d
        c.drawCircle(cx, cy, r, halka)

        // Sabit işaret: telefonun baktığı yön (üstte)
        val ok = Path()
        ok.moveTo(cx - 10f * d, cy - r - 12f * d)
        ok.lineTo(cx + 10f * d, cy - r - 12f * d)
        ok.lineTo(cx, cy - r + 2f * d)
        ok.close()
        dolgu.color = krem
        c.drawPath(ok, dolgu)

        // Merkez nokta
        dolgu.color = altin
        c.drawCircle(cx, cy, 5f * d, dolgu)

        if (hizali) {
            yazi.color = altin
            yazi.textSize = 15f * d
            c.drawText("Kıble yönündesin", cx, cy + r * 0.45f, yazi)
        }
    }
}
