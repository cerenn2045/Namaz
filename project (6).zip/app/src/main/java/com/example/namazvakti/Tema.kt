package com.example.namazvakti

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

object Tema {
    val ZEMIN = Color.parseColor("#0B3B2E")
    val KART = Color.parseColor("#14543F")
    val ALTIN = Color.parseColor("#D4AF37")
    val KREM = Color.parseColor("#F5EFD9")
    val SOLUK = Color.parseColor("#A9C2B5")
    const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun arkaplan(c: Context, renk: Int, yaricap: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(renk)
        g.cornerRadius = dp(c, yaricap).toFloat()
        return g
    }

    fun yazi(c: Context, metin: String, boyut: Float, renk: Int, kalin: Boolean = false): TextView {
        val t = TextView(c)
        t.text = metin
        t.textSize = boyut
        t.setTextColor(renk)
        if (kalin) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    fun kart(c: Context): LinearLayout {
        val k = LinearLayout(c)
        k.orientation = LinearLayout.VERTICAL
        k.background = arkaplan(c, KART, 16)
        k.setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14))
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.setMargins(0, 0, 0, dp(c, 12))
        k.layoutParams = lp
        return k
    }

    fun dugme(c: Context, metin: String): Button {
        val b = Button(c)
        b.text = metin
        b.transformationMethod = null
        b.setTextColor(ZEMIN)
        b.setTypeface(b.typeface, Typeface.BOLD)
        b.background = arkaplan(c, ALTIN, 12)
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.setMargins(0, dp(c, 10), 0, 0)
        b.layoutParams = lp
        return b
    }
}
