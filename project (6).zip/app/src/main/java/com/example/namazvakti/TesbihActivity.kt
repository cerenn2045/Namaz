package com.example.namazvakti

import android.app.Activity
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Typeface

class TesbihActivity : Activity() {

    private class Zikir(
        val baslik: String,
        val arapca: String,
        val okunus: String,
        val anlam: String,
        val hedef: Int
    )

    private val subhanallah = Zikir(
        "Sübhânallâh", "سُبْحَانَ اللَّهِ", "Sübhânallâh",
        "Allah her türlü eksiklikten uzaktır.", 33
    )
    private val elhamdulillah = Zikir(
        "Elhamdülillâh", "الْحَمْدُ لِلَّهِ", "Elhamdülillâh",
        "Hamd Allah'a mahsustur.", 33
    )
    private val allahuEkber = Zikir(
        "Allâhü ekber", "اللَّهُ أَكْبَرُ", "Allâhü ekber",
        "Allah en büyüktür.", 33
    )
    private val tamamlama = Zikir(
        "Tamamlama duası",
        "لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ",
        "Lâ ilâhe illallâhü vahdehû lâ şerîke leh, lehül mülkü ve lehül hamdü ve hüve alâ külli şey'in kadîr.",
        "Allah'tan başka ilah yoktur. O tektir, ortağı yoktur. Mülk O'nundur, hamd O'nadır ve O her şeye kadirdir.", 1
    )

    private val tesbihat = listOf(subhanallah, elhamdulillah, allahuEkber, tamamlama)
    private val serbest = listOf(
        subhanallah, elhamdulillah, allahuEkber,
        Zikir("Lâ ilâhe illallâh", "لَا إِلَٰهَ إِلَّا اللَّهُ", "Lâ ilâhe illallâh", "Allah'tan başka ilah yoktur.", 33),
        Zikir("Estağfirullâh", "أَسْتَغْفِرُ اللَّهَ", "Estağfirullâh", "Allah'tan bağışlanma dilerim.", 33),
        Zikir("Salavat", "اللَّهُمَّ صَلِّ عَلَىٰ سَيِّدِنَا مُحَمَّدٍ", "Allâhümme salli alâ seyyidinâ Muhammed", "Allah'ım! Efendimiz Muhammed'e rahmet et.", 33),
        Zikir("Lâ havle", "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ", "Lâ havle ve lâ kuvvete illâ billâh", "Güç ve kuvvet ancak Allah'tandır.", 33)
    )

    private var mod = 0      // 0 = tesbihat, 1 = serbest
    private var asama = 0
    private var sayac = 0
    private var sIndex = 0
    private var sSayac = 0

    private lateinit var adimYazi: TextView
    private lateinit var arapcaYazi: TextView
    private lateinit var okunusYazi: TextView
    private lateinit var anlamYazi: TextView
    private lateinit var sayacYazi: TextView
    private lateinit var altYazi: TextView
    private lateinit var tesbihatDugme: TextView
    private lateinit var serbestDugme: TextView
    private lateinit var secimSatiri: HorizontalScrollView
    private val secimDugmeleri = ArrayList<TextView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Tema.ZEMIN
        window.navigationBarColor = Tema.ZEMIN
        window.decorView.setBackgroundColor(Tema.ZEMIN)

        val ayar = getSharedPreferences("tesbih", MODE_PRIVATE)
        mod = ayar.getInt("mod", 0)
        asama = ayar.getInt("asama", 0)
        sayac = ayar.getInt("sayac", 0)
        sIndex = ayar.getInt("sIndex", 0).coerceIn(0, serbest.size - 1)
        sSayac = ayar.getInt("sSayac", 0)

        val kok = LinearLayout(this)
        kok.orientation = LinearLayout.VERTICAL
        kok.setPadding(Tema.dp(this, 16), Tema.dp(this, 24), Tema.dp(this, 16), Tema.dp(this, 24))

        val geri = Tema.yazi(this, "‹ Geri", 16f, Tema.ALTIN, true)
        geri.setPadding(0, Tema.dp(this, 8), Tema.dp(this, 16), Tema.dp(this, 12))
        geri.setOnClickListener { finish() }
        kok.addView(geri)

        val baslik = Tema.yazi(this, "Tesbih", 28f, Tema.ALTIN, true)
        baslik.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        baslik.setPadding(0, 0, 0, Tema.dp(this, 12))
        kok.addView(baslik)

        // Mod düğmeleri
        val modSatiri = LinearLayout(this)
        modSatiri.orientation = LinearLayout.HORIZONTAL
        val modLp = LinearLayout.LayoutParams(Tema.MATCH, Tema.WRAP)
        modLp.setMargins(0, 0, 0, Tema.dp(this, 12))
        modSatiri.layoutParams = modLp
        tesbihatDugme = modDugmesi("Namaz sonrası tesbihat")
        serbestDugme = modDugmesi("Serbest sayaç")
        tesbihatDugme.setOnClickListener { modSec(0) }
        serbestDugme.setOnClickListener { modSec(1) }
        modSatiri.addView(tesbihatDugme)
        modSatiri.addView(serbestDugme)
        kok.addView(modSatiri)

        // Serbest moddaki zikir seçimi
        secimSatiri = HorizontalScrollView(this)
        secimSatiri.isHorizontalScrollBarEnabled = false
        val secimIci = LinearLayout(this)
        secimIci.orientation = LinearLayout.HORIZONTAL
        for ((i, z) in serbest.withIndex()) {
            val t = Tema.yazi(this, z.baslik, 14f, Tema.KREM, true)
            t.setPadding(Tema.dp(this, 14), Tema.dp(this, 8), Tema.dp(this, 14), Tema.dp(this, 8))
            val lp = LinearLayout.LayoutParams(Tema.WRAP, Tema.WRAP)
            lp.setMargins(0, 0, Tema.dp(this, 8), Tema.dp(this, 12))
            t.layoutParams = lp
            t.setOnClickListener {
                sIndex = i
                sSayac = 0
                kaydet()
                ciz()
            }
            secimDugmeleri.add(t)
            secimIci.addView(t)
        }
        secimSatiri.addView(secimIci)
        kok.addView(secimSatiri)

        // Zikir kartı
        val kart = Tema.kart(this)
        kart.gravity = Gravity.CENTER_HORIZONTAL
        adimYazi = Tema.yazi(this, "", 14f, Tema.ALTIN, true)
        adimYazi.gravity = Gravity.CENTER_HORIZONTAL
        arapcaYazi = Tema.yazi(this, "", 30f, Tema.KREM)
        arapcaYazi.textDirection = View.TEXT_DIRECTION_RTL
        arapcaYazi.gravity = Gravity.CENTER_HORIZONTAL
        arapcaYazi.setLineSpacing(0f, 1.3f)
        arapcaYazi.setPadding(0, Tema.dp(this, 10), 0, 0)
        okunusYazi = Tema.yazi(this, "", 15f, Tema.KREM)
        okunusYazi.typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC)
        okunusYazi.gravity = Gravity.CENTER_HORIZONTAL
        okunusYazi.setPadding(0, Tema.dp(this, 6), 0, 0)
        anlamYazi = Tema.yazi(this, "", 13f, Tema.SOLUK)
        anlamYazi.gravity = Gravity.CENTER_HORIZONTAL
        anlamYazi.setPadding(0, Tema.dp(this, 4), 0, 0)
        kart.addView(adimYazi)
        kart.addView(arapcaYazi)
        kart.addView(okunusYazi)
        kart.addView(anlamYazi)
        kok.addView(kart)

        // Büyük sayaç düğmesi
        val daire = GradientDrawable()
        daire.shape = GradientDrawable.OVAL
        daire.setColor(Tema.ALTIN)
        daire.setStroke(Tema.dp(this, 5), Tema.KREM)
        sayacYazi = Tema.yazi(this, "0", 64f, Tema.ZEMIN, true)
        sayacYazi.gravity = Gravity.CENTER
        sayacYazi.background = daire
        val boy = Tema.dp(this, 210)
        val sayacLp = LinearLayout.LayoutParams(boy, boy)
        sayacLp.gravity = Gravity.CENTER_HORIZONTAL
        sayacLp.setMargins(0, Tema.dp(this, 8), 0, Tema.dp(this, 12))
        sayacYazi.layoutParams = sayacLp
        sayacYazi.setOnClickListener { artir(it) }
        kok.addView(sayacYazi)

        altYazi = Tema.yazi(this, "", 15f, Tema.KREM)
        altYazi.gravity = Gravity.CENTER_HORIZONTAL
        kok.addView(altYazi)

        val sifirla = Tema.dugme(this, "Sıfırla")
        sifirla.setOnClickListener {
            if (mod == 0) {
                asama = 0
                sayac = 0
            } else {
                sSayac = 0
            }
            kaydet()
            ciz()
        }
        kok.addView(sifirla)

        val kaydirma = ScrollView(this)
        kaydirma.setBackgroundColor(Tema.ZEMIN)
        kaydirma.addView(kok)
        setContentView(kaydirma)
        ciz()
    }

    private fun modDugmesi(metin: String): TextView {
        val t = Tema.yazi(this, metin, 14f, Tema.KREM, true)
        t.gravity = Gravity.CENTER
        t.setPadding(Tema.dp(this, 8), Tema.dp(this, 12), Tema.dp(this, 8), Tema.dp(this, 12))
        val lp = LinearLayout.LayoutParams(0, Tema.WRAP, 1f)
        lp.setMargins(Tema.dp(this, 3), 0, Tema.dp(this, 3), 0)
        t.layoutParams = lp
        return t
    }

    private fun boya(t: TextView, secili: Boolean) {
        t.background = Tema.arkaplan(this, if (secili) Tema.ALTIN else Tema.KART, 12)
        t.setTextColor(if (secili) Tema.ZEMIN else Tema.KREM)
    }

    private fun modSec(yeni: Int) {
        mod = yeni
        kaydet()
        ciz()
    }

    private fun kaydet() {
        getSharedPreferences("tesbih", MODE_PRIVATE).edit()
            .putInt("mod", mod).putInt("asama", asama).putInt("sayac", sayac)
            .putInt("sIndex", sIndex).putInt("sSayac", sSayac)
            .apply()
    }

    private fun artir(v: View) {
        v.animate().scaleX(0.93f).scaleY(0.93f).setDuration(50).withEndAction {
            v.animate().scaleX(1f).scaleY(1f).setDuration(90).start()
        }.start()
        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)

        if (mod == 0) {
            if (asama >= tesbihat.size) return
            sayac++
            if (sayac >= tesbihat[asama].hedef) {
                sayac = 0
                asama++
                uzunTitret()
            }
        } else {
            sSayac++
            if (sSayac % 33 == 0) uzunTitret()
        }
        kaydet()
        ciz()
    }

    private fun uzunTitret() {
        try {
            val titresim = getSystemService(VIBRATOR_SERVICE) as Vibrator
            titresim.vibrate(VibrationEffect.createOneShot(350, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) {
            // Titreşim yoksa sessizce geç.
        }
    }

    private fun ciz() {
        boya(tesbihatDugme, mod == 0)
        boya(serbestDugme, mod == 1)
        secimSatiri.visibility = if (mod == 1) View.VISIBLE else View.GONE
        for ((i, t) in secimDugmeleri.withIndex()) boya(t, i == sIndex)

        if (mod == 0) {
            if (asama >= tesbihat.size) {
                adimYazi.text = "Tesbihat tamamlandı. Allah kabul etsin."
                arapcaYazi.text = ""
                okunusYazi.text = ""
                anlamYazi.text = ""
                sayacYazi.text = "Bitti"
                sayacYazi.textSize = 40f
                altYazi.text = "Yeniden başlamak için Sıfırla'ya bas."
            } else {
                val z = tesbihat[asama]
                adimYazi.text = "${asama + 1}/${tesbihat.size}. adım • ${z.baslik}" +
                    (if (z.hedef > 1) " • ${z.hedef} kez" else "")
                arapcaYazi.text = z.arapca
                arapcaYazi.textSize = if (z.hedef > 1) 30f else 22f
                okunusYazi.text = z.okunus
                anlamYazi.text = z.anlam
                sayacYazi.text = sayac.toString()
                sayacYazi.textSize = 64f
                altYazi.text = if (z.hedef > 1) "$sayac / ${z.hedef}"
                else "Okuduktan sonra bir kez dokun."
            }
        } else {
            val z = serbest[sIndex]
            adimYazi.text = z.baslik
            arapcaYazi.text = z.arapca
            arapcaYazi.textSize = 30f
            okunusYazi.text = z.okunus
            anlamYazi.text = z.anlam
            sayacYazi.text = sSayac.toString()
            sayacYazi.textSize = 64f
            altYazi.text = "Toplam: $sSayac • Her 33'te bir titreşir"
        }
    }
}
