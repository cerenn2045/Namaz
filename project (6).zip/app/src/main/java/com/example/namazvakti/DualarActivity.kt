package com.example.namazvakti

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class DualarActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Tema.ZEMIN
        window.navigationBarColor = Tema.ZEMIN
        window.decorView.setBackgroundColor(Tema.ZEMIN)

        val kok = LinearLayout(this)
        kok.orientation = LinearLayout.VERTICAL
        kok.setPadding(Tema.dp(this, 16), Tema.dp(this, 24), Tema.dp(this, 16), Tema.dp(this, 24))

        val geri = Tema.yazi(this, "‹ Geri", 16f, Tema.ALTIN, true)
        geri.setPadding(0, Tema.dp(this, 8), Tema.dp(this, 16), Tema.dp(this, 12))
        geri.setOnClickListener { finish() }
        kok.addView(geri)

        val baslik = Tema.yazi(this, "Namaz Duaları", 28f, Tema.ALTIN, true)
        baslik.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        kok.addView(baslik)

        val not = Tema.yazi(
            this,
            "Bir dua üzerine dokunarak aç/kapat. Anlamlar özet niteliğindedir; Arapça metinleri Diyanet veya bir din görevlisinin kaynaklarıyla karşılaştırarak kullan.",
            13f, Tema.SOLUK
        )
        not.setPadding(0, Tema.dp(this, 4), 0, Tema.dp(this, 12))
        kok.addView(not)

        var sonGrup = ""
        for (d in DuaListesi.liste) {
            if (d.grup != sonGrup) {
                val g = Tema.yazi(this, d.grup, 16f, Tema.ALTIN, true)
                g.setPadding(Tema.dp(this, 4), Tema.dp(this, 12), 0, Tema.dp(this, 8))
                kok.addView(g)
                sonGrup = d.grup
            }
            kok.addView(duaKarti(d))
        }

        val kaydirma = ScrollView(this)
        kaydirma.setBackgroundColor(Tema.ZEMIN)
        kaydirma.addView(kok)
        setContentView(kaydirma)
    }

    private fun etiket(metin: String): TextView {
        val t = Tema.yazi(this, metin, 12f, Tema.ALTIN, true)
        t.setPadding(0, Tema.dp(this, 12), 0, Tema.dp(this, 2))
        return t
    }

    private fun duaKarti(d: Dua): LinearLayout {
        val kart = Tema.kart(this)

        val ust = LinearLayout(this)
        ust.orientation = LinearLayout.HORIZONTAL
        ust.gravity = Gravity.CENTER_VERTICAL
        val ad = Tema.yazi(this, d.baslik, 18f, Tema.KREM, true)
        ad.layoutParams = LinearLayout.LayoutParams(0, Tema.WRAP, 1f)
        val isaret = Tema.yazi(this, "+", 24f, Tema.ALTIN, true)
        ust.addView(ad)
        ust.addView(isaret)
        kart.addView(ust)

        val icerik = LinearLayout(this)
        icerik.orientation = LinearLayout.VERTICAL
        icerik.visibility = View.GONE

        val arapca = Tema.yazi(this, d.arapca, 24f, Tema.KREM)
        arapca.textDirection = View.TEXT_DIRECTION_RTL
        arapca.gravity = Gravity.CENTER_HORIZONTAL
        arapca.setLineSpacing(0f, 1.4f)
        arapca.setPadding(0, Tema.dp(this, 12), 0, 0)
        icerik.addView(arapca)

        icerik.addView(etiket("Okunuşu"))
        val okunus = Tema.yazi(this, d.okunus, 15f, Tema.KREM)
        okunus.typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC)
        okunus.setLineSpacing(0f, 1.15f)
        icerik.addView(okunus)

        icerik.addView(etiket("Anlamı"))
        val anlam = Tema.yazi(this, d.anlam, 14f, Tema.SOLUK)
        anlam.setLineSpacing(0f, 1.15f)
        icerik.addView(anlam)

        kart.addView(icerik)

        kart.setOnClickListener {
            val acik = icerik.visibility == View.VISIBLE
            icerik.visibility = if (acik) View.GONE else View.VISIBLE
            isaret.text = if (acik) "+" else "−"
        }
        return kart
    }
}
