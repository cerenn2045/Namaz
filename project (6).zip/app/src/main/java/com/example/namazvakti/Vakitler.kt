package com.example.namazvakti

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

class GunVerisi(
    val bolge: ZoneId,
    val saatler: Map<String, LocalTime>,
    val enlem: Double,
    val boylam: Double
)

object Vakitler {

    val adlar = listOf("Sabah", "Öğle", "İkindi", "Akşam", "Yatsı")
    private val anahtarlar = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")
    private const val KANAL_EZAN = "vakit_ezan_v2"
    private const val KANAL_NORMAL = "vakit_normal_v2"
    private val TITRESIM = longArrayOf(0, 600, 300, 600, 300, 900)

    fun ezanVarMi(ctx: Context): Boolean =
        ctx.resources.getIdentifier("ezan", "raw", ctx.packageName) != 0

    // Aladhan API, yöntem 13 = Diyanet İşleri Başkanlığı
    private fun gunuGetir(sehir: String, gun: LocalDate): GunVerisi {
        val tarih = gun.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"))
        val adres = "https://api.aladhan.com/v1/timingsByCity/$tarih" +
            "?city=${URLEncoder.encode(sehir, "UTF-8")}&country=Turkey&method=13"
        val baglanti = URL(adres).openConnection() as HttpURLConnection
        baglanti.connectTimeout = 8000
        baglanti.readTimeout = 8000
        val metin = baglanti.inputStream.bufferedReader().use { it.readText() }
        baglanti.disconnect()

        val veri = JSONObject(metin).getJSONObject("data")
        val zamanlar = veri.getJSONObject("timings")
        val meta = veri.getJSONObject("meta")
        val bolge = ZoneId.of(meta.getString("timezone"))
        val sonuc = LinkedHashMap<String, LocalTime>()
        for (k in listOf("Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha")) {
            sonuc[k] = LocalTime.parse(zamanlar.getString(k).substring(0, 5))
        }
        return GunVerisi(bolge, sonuc, meta.optDouble("latitude", Double.NaN), meta.optDouble("longitude", Double.NaN))
    }

    // Kayıtlı vakitleri okur (ana ekran için).
    fun gunVerisi(ctx: Context, gun: LocalDate): Map<String, LocalTime>? {
        val depo = ctx.getSharedPreferences("ayar", Context.MODE_PRIVATE)
            .getString("gun_${gun.toEpochDay()}", null) ?: return null
        val sonuc = LinkedHashMap<String, LocalTime>()
        for (parca in depo.split(";")) {
            val kv = parca.split("=")
            if (kv.size == 2) sonuc[kv[0]] = LocalTime.parse(kv[1])
        }
        return sonuc
    }

    // Önümüzdeki 3 günün vakitlerini alıp alarmları kurar. Arka plan thread'inde çağır.
    fun planla(ctx: Context): String {
        val ayar = ctx.getSharedPreferences("ayar", Context.MODE_PRIVATE)
        val sehir = ayar.getString("sehir", "Bursa") ?: "Bursa"
        val kayma = ayar.getInt("kayma", 0)
        val alarmYonetici = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val simdi = System.currentTimeMillis()
        val baslangic = LocalDate.now()
        var ozet = ""

        for (i in 0..2) {
            val gun = baslangic.plusDays(i.toLong())
            try {
                val gv = gunuGetir(sehir, gun)
                val bolge = gv.bolge
                val saatler = gv.saatler
                val depo = saatler.entries.joinToString(";") { "${it.key}=${it.value}" }
                val duzenle = ayar.edit()
                duzenle.putString("gun_${gun.toEpochDay()}", depo).putString("bolge", bolge.id)
                if (!gv.enlem.isNaN() && !gv.boylam.isNaN()) {
                    duzenle.putString("enlem", gv.enlem.toString()).putString("boylam", gv.boylam.toString())
                }
                for (anahtar in ayar.all.keys) {
                    if (anahtar.startsWith("gun_")) {
                        val g = anahtar.substring(4).toLongOrNull()
                        if (g != null && g < baslangic.toEpochDay() - 1) duzenle.remove(anahtar)
                    }
                }
                duzenle.apply()
                for (j in 0..4) {
                    val saat = saatler[anahtarlar[j]]!!
                    val vakitMs = ZonedDateTime.of(gun, saat, bolge).toInstant().toEpochMilli()
                    val ms = vakitMs + kayma * 60_000L
                    if (ms > simdi) alarmKur(ctx, alarmYonetici, gun, j, ms) else alarmIptal(ctx, alarmYonetici, gun, j)
                }
                if (i == 0) {
                    ozet = "$sehir için bugünün vakitleri (Diyanet):\n\n" +
                        "Sabah:  ${saatler["Fajr"]}\n" +
                        "Güneş:  ${saatler["Sunrise"]}\n" +
                        "Öğle:   ${saatler["Dhuhr"]}\n" +
                        "İkindi: ${saatler["Asr"]}\n" +
                        "Akşam:  ${saatler["Maghrib"]}\n" +
                        "Yatsı:  ${saatler["Isha"]}\n\n" +
                        (if (kayma < 0) "Bildirimler vakitten ${-kayma} dk önce gelir.\n"
                        else if (kayma > 0) "Bildirimler vakitten $kayma dk sonra gelir.\n" else "") +
                        "Alarmlar kuruldu."
                }
            } catch (e: Exception) {
                if (i == 0) throw e
            }
        }
        ayar.edit().putString("ozet", ozet).apply()
        return ozet
    }

    private fun niyet(ctx: Context, gun: LocalDate, j: Int): Intent {
        val n = Intent(ctx, AlarmReceiver::class.java)
        n.putExtra("j", j)
        n.putExtra("gun", gun.toEpochDay())
        return n
    }

    // Aynı gün+vakit her zaman aynı kodu alır, böylece çift alarm oluşmaz.
    private fun kod(gun: LocalDate, j: Int): Int = (gun.toEpochDay() % 100000).toInt() * 10 + j

    private fun alarmKur(ctx: Context, am: AlarmManager, gun: LocalDate, j: Int, ms: Long) {
        val pi = PendingIntent.getBroadcast(
            ctx, kod(gun, j), niyet(ctx, gun, j),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
        }
    }

    private fun alarmIptal(ctx: Context, am: AlarmManager, gun: LocalDate, j: Int) {
        val pi = PendingIntent.getBroadcast(
            ctx, kod(gun, j), niyet(ctx, gun, j),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pi != null) am.cancel(pi)
    }

    // Ezan sesi dosyası varsa ve açıksa ezanlı kanalı, yoksa normal kanalı kullanır.
    // Her ikisinde de güçlü titreşim vardır.
    private fun kanalSec(ctx: Context): String {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.deleteNotificationChannel("vakit_kanali")
        val ayar = ctx.getSharedPreferences("ayar", Context.MODE_PRIVATE)
        val ezanIstiyor = ayar.getBoolean("ezan", true) && ezanVarMi(ctx)

        if (ezanIstiyor) {
            val k = NotificationChannel(KANAL_EZAN, "Namaz vakti (ezan sesi)", NotificationManager.IMPORTANCE_HIGH)
            k.enableVibration(true)
            k.vibrationPattern = TITRESIM
            val ses = Uri.parse("android.resource://${ctx.packageName}/raw/ezan")
            val ozellik = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            k.setSound(ses, ozellik)
            nm.createNotificationChannel(k)
            return KANAL_EZAN
        }

        val k = NotificationChannel(KANAL_NORMAL, "Namaz vakti", NotificationManager.IMPORTANCE_HIGH)
        k.enableVibration(true)
        k.vibrationPattern = TITRESIM
        nm.createNotificationChannel(k)
        return KANAL_NORMAL
    }

    fun bildir(ctx: Context, j: Int, gun: Long) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val kanal = kanalSec(ctx)
        val kayma = ctx.getSharedPreferences("ayar", Context.MODE_PRIVATE).getInt("kayma", 0)
        val baslik = when {
            kayma < 0 -> "${adlar[j]} namazına ${-kayma} dakika var"
            kayma > 0 -> "${adlar[j]} namazı vakti ($kayma dk önce girdi)"
            else -> "${adlar[j]} namazı vakti"
        }
        val icerik = Icerik.sec(j, gun)
        val dokun = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val bildirim = NotificationCompat.Builder(ctx, kanal)
            .setSmallIcon(R.drawable.ic_bildirim)
            .setContentTitle(baslik)
            .setContentText(icerik)
            .setStyle(NotificationCompat.BigTextStyle().bigText(icerik))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(dokun)
            .setAutoCancel(true)
            .build()
        nm.notify(200 + j, bildirim)
    }
}
