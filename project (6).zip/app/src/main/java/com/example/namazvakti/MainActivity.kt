package com.example.namazvakti

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.time.Duration
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Locale

class MainActivity : Activity(), SensorEventListener {

    // Yeşil ve altın renk paleti
    private val ZEMIN = Color.parseColor("#0B3B2E")
    private val KART = Color.parseColor("#14543F")
    private val ALTIN = Color.parseColor("#D4AF37")
    private val KREM = Color.parseColor("#F5EFD9")
    private val SOLUK = Color.parseColor("#A9C2B5")

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val gorunenAd = listOf("Sabah", "Güneş", "Öğle", "İkindi", "Akşam", "Yatsı")
    private val gorunenAnahtar = listOf("Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha")
    private val besVakitAnahtar = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")
    private val besVakitSatir = listOf(0, 2, 3, 4, 5) // 5 vaktin, 6 satırlı listedeki yeri

    private lateinit var sehirYazi: TextView
    private lateinit var sonrakiYazi: TextView
    private lateinit var geriSayimYazi: TextView
    private lateinit var vakitlerKutusu: LinearLayout
    private lateinit var durumYazi: TextView
    private lateinit var sehirKutusu: EditText
    private lateinit var kaymaKutusu: EditText
    private lateinit var ezanKutusu: CheckBox
    private lateinit var pusula: PusulaGorunumu
    private lateinit var kibleYazi: TextView
    private lateinit var kalibreYazi: TextView
    private var sensorYoneticisi: SensorManager? = null
    private var sapma = 0f
    private var kibleAcisi = Double.NaN
    private var sinOrt = 0.0
    private var cosOrt = 1.0
    private var ilkOlcum = true

    private var sonGosterilen = -2
    private val handler = Handler(Looper.getMainLooper())
    private val saniye = object : Runnable {
        override fun run() {
            sayimiGuncelle()
            handler.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun arkaplan(renk: Int, yaricap: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(renk)
        g.cornerRadius = dp(yaricap).toFloat()
        return g
    }

    private fun yazi(metin: String, boyut: Float, renk: Int, kalin: Boolean = false): TextView {
        val t = TextView(this)
        t.text = metin
        t.textSize = boyut
        t.setTextColor(renk)
        if (kalin) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun kart(): LinearLayout {
        val k = LinearLayout(this)
        k.orientation = LinearLayout.VERTICAL
        k.background = arkaplan(KART, 16)
        k.setPadding(dp(16), dp(14), dp(16), dp(14))
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.setMargins(0, 0, 0, dp(12))
        k.layoutParams = lp
        return k
    }

    private fun alan(ipucu: String): EditText {
        val e = EditText(this)
        e.hint = ipucu
        e.setTextColor(KREM)
        e.setHintTextColor(SOLUK)
        e.setSingleLine()
        e.backgroundTintList = ColorStateList.valueOf(ALTIN)
        return e
    }

    private fun dugme(metin: String): Button {
        val b = Button(this)
        b.text = metin
        b.transformationMethod = null
        b.setTextColor(ZEMIN)
        b.setTypeface(b.typeface, Typeface.BOLD)
        b.background = arkaplan(ALTIN, 12)
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.setMargins(0, dp(10), 0, 0)
        b.layoutParams = lp
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = ZEMIN
        window.navigationBarColor = ZEMIN
        window.decorView.setBackgroundColor(ZEMIN)
        val ayar = getSharedPreferences("ayar", MODE_PRIVATE)

        val kok = LinearLayout(this)
        kok.orientation = LinearLayout.VERTICAL
        kok.setPadding(dp(16), dp(24), dp(16), dp(24))

        // Başlık
        val baslik = yazi("Vakitname", 30f, ALTIN, true)
        baslik.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        kok.addView(baslik)
        sehirYazi = yazi("${selam()} • ${ayar.getString("sehir", "Bursa") ?: "Bursa"}", 15f, SOLUK)
        sehirYazi.setPadding(0, 0, 0, dp(16))
        kok.addView(sehirYazi)

        // Geri sayım kartı
        val sayimKarti = kart()
        sayimKarti.gravity = Gravity.CENTER_HORIZONTAL
        sonrakiYazi = yazi("Vakitler alınıyor...", 15f, SOLUK)
        sonrakiYazi.gravity = Gravity.CENTER_HORIZONTAL
        geriSayimYazi = yazi("--:--:--", 46f, ALTIN, true)
        geriSayimYazi.gravity = Gravity.CENTER_HORIZONTAL
        sayimKarti.addView(sonrakiYazi)
        sayimKarti.addView(geriSayimYazi)
        kok.addView(sayimKarti)

        // Kısayollar: Tesbih ve Dualar
        val kisayollar = LinearLayout(this)
        kisayollar.orientation = LinearLayout.HORIZONTAL
        val kisayolLp = LinearLayout.LayoutParams(MATCH, WRAP)
        kisayolLp.setMargins(0, 0, 0, dp(12))
        kisayollar.layoutParams = kisayolLp
        kisayollar.addView(kisayol("Tesbih", TesbihActivity::class.java))
        kisayollar.addView(kisayol("Dualar", DualarActivity::class.java))
        kok.addView(kisayollar)

        // Vakit kartları
        vakitlerKutusu = kart()
        vakitlerKutusu.setPadding(dp(8), dp(8), dp(8), dp(8))
        kok.addView(vakitlerKutusu)

        // Kıble pusulası
        val kibleKarti = kart()
        kibleKarti.addView(yazi("Kıble pusulası", 18f, ALTIN, true))
        val kibleAciklama = yazi(
            "Telefonu yere paralel (düz) tut. Altın Kâbe işareti en üstteki sabit işaretle çakışınca kıbleye dönüksün.",
            13f, SOLUK
        )
        kibleAciklama.setPadding(0, dp(4), 0, dp(8))
        kibleKarti.addView(kibleAciklama)
        pusula = PusulaGorunumu(this)
        val pusulaLp = LinearLayout.LayoutParams(WRAP, WRAP)
        pusulaLp.gravity = Gravity.CENTER_HORIZONTAL
        pusula.layoutParams = pusulaLp
        kibleKarti.addView(pusula)
        kibleYazi = yazi("Konum bekleniyor...", 15f, KREM)
        kibleYazi.gravity = Gravity.CENTER_HORIZONTAL
        kibleYazi.setPadding(0, dp(8), 0, 0)
        kibleKarti.addView(kibleYazi)
        kalibreYazi = yazi("", 12f, SOLUK)
        kalibreYazi.gravity = Gravity.CENTER_HORIZONTAL
        kibleKarti.addView(kalibreYazi)
        kok.addView(kibleKarti)

        // Günün ayeti / hadisi
        val ayetKarti = kart()
        ayetKarti.addView(yazi("Günün ayeti / hadisi", 13f, ALTIN, true))
        val ayet = yazi(Icerik.gunun(LocalDate.now().toEpochDay()), 16f, KREM)
        ayet.typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC)
        ayet.setPadding(0, dp(8), 0, 0)
        ayet.setLineSpacing(0f, 1.15f)
        ayetKarti.addView(ayet)
        kok.addView(ayetKarti)

        // Ayarlar
        val ayarKarti = kart()
        ayarKarti.addView(yazi("Ayarlar", 18f, ALTIN, true))

        sehirKutusu = alan("Şehir (örn. Bursa)")
        sehirKutusu.setText(ayar.getString("sehir", "Bursa"))
        ayarKarti.addView(sehirKutusu)

        val kaymaYazi = yazi(
            "Bildirim kaç dakika kaysın? (-10 = vakitten 10 dk önce, 0 = tam vakitte, 5 = 5 dk sonra)",
            13f, SOLUK
        )
        kaymaYazi.setPadding(0, dp(12), 0, 0)
        ayarKarti.addView(kaymaYazi)

        kaymaKutusu = alan("0")
        kaymaKutusu.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
        kaymaKutusu.setText(ayar.getInt("kayma", 0).toString())
        ayarKarti.addView(kaymaKutusu)

        ezanKutusu = CheckBox(this)
        ezanKutusu.text = "Ezan sesi kullan"
        ezanKutusu.setTextColor(KREM)
        ezanKutusu.buttonTintList = ColorStateList.valueOf(ALTIN)
        ezanKutusu.isChecked = ayar.getBoolean("ezan", true)
        ezanKutusu.isEnabled = Vakitler.ezanVarMi(this)
        ayarKarti.addView(ezanKutusu)

        ayarKarti.addView(
            yazi(
                if (Vakitler.ezanVarMi(this)) "Ezan ses dosyası bulundu."
                else "Ezan ses dosyası yok. Depoya ezan.mp3 yükleyip yeniden derletirsen eklenir.",
                13f, SOLUK
            )
        )

        val kaydet = dugme("Kaydet ve alarmları kur")
        kaydet.setOnClickListener { kur() }
        ayarKarti.addView(kaydet)

        val deneme = dugme("Deneme bildirimi gönder")
        deneme.setOnClickListener {
            Vakitler.bildir(this, 0, LocalDate.now().toEpochDay())
        }
        ayarKarti.addView(deneme)

        durumYazi = yazi("", 14f, KREM)
        durumYazi.setPadding(0, dp(12), 0, 0)
        ayarKarti.addView(durumYazi)
        kok.addView(ayarKarti)

        val not = yazi(
            "Bildirimler gecikirse Ayarlar > Uygulamalar > Vakitname > Pil bölümünden " +
                "\"Kısıtlanmamış\" seçeneğini işaretle. Titreşimi veya sesi telefonun bildirim " +
                "ayarlarından (Namaz vakti kanalı) da değiştirebilirsin.",
            12f, SOLUK
        )
        kok.addView(not)

        val kaydirma = ScrollView(this)
        kaydirma.setBackgroundColor(ZEMIN)
        kaydirma.addView(kok)
        setContentView(kaydirma)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        sensorYoneticisi = getSystemService(SENSOR_SERVICE) as SensorManager
        konumuYukle()
        kartlariCiz()
        kur()
    }

    private fun kisayol(metin: String, hedef: Class<*>): TextView {
        val t = yazi(metin, 18f, ZEMIN, true)
        t.gravity = Gravity.CENTER
        t.background = arkaplan(ALTIN, 16)
        t.setPadding(dp(8), dp(18), dp(8), dp(18))
        val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
        lp.setMargins(dp(4), 0, dp(4), 0)
        t.layoutParams = lp
        t.setOnClickListener { startActivity(Intent(this, hedef)) }
        return t
    }

    private fun selam(): String {
        val saat = java.time.LocalTime.now().hour
        return when {
            saat in 5..10 -> "Hayırlı sabahlar"
            saat in 11..16 -> "Hayırlı günler"
            saat in 17..21 -> "Hayırlı akşamlar"
            else -> "Hayırlı geceler"
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(saniye)
        val sm = sensorYoneticisi
        val sensor = sm?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (sm != null && sensor != null) {
            sm.registerListener(this, sensor, SensorManager.SENSOR_DELAY_UI)
        } else {
            kalibreYazi.text = "Bu telefonda pusula sensörü bulunamadı."
        }
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(saniye)
        sensorYoneticisi?.unregisterListener(this)
    }

    // Şehrin koordinatından Kâbe'ye yönü ve mesafeyi hesaplar.
    private fun konumuYukle() {
        val ayar = getSharedPreferences("ayar", MODE_PRIVATE)
        val enlem = ayar.getString("enlem", null)?.toDoubleOrNull()
        val boylam = ayar.getString("boylam", null)?.toDoubleOrNull()
        if (enlem == null || boylam == null) return
        val k1 = Math.toRadians(enlem)
        val l1 = Math.toRadians(boylam)
        val k2 = Math.toRadians(21.4225)
        val l2 = Math.toRadians(39.8262)
        val dl = l2 - l1
        val aci = Math.toDegrees(
            Math.atan2(
                Math.sin(dl) * Math.cos(k2),
                Math.cos(k1) * Math.sin(k2) - Math.sin(k1) * Math.cos(k2) * Math.cos(dl)
            )
        )
        kibleAcisi = (aci + 360.0) % 360.0
        val dk = k2 - k1
        val a = Math.sin(dk / 2) * Math.sin(dk / 2) +
            Math.cos(k1) * Math.cos(k2) * Math.sin(dl / 2) * Math.sin(dl / 2)
        val km = 2 * 6371.0 * Math.asin(Math.sqrt(a))
        sapma = GeomagneticField(enlem.toFloat(), boylam.toFloat(), 0f, System.currentTimeMillis()).declination
        pusula.kibleAcisi = kibleAcisi.toFloat()
        pusula.hazir = true
        val kmMetni = String.format(Locale("tr", "TR"), "%,.0f", km)
        kibleYazi.text = String.format(Locale.US, "Kıble: %.0f°", kibleAcisi) + " • Kâbe'ye yaklaşık $kmMetni km"
        pusula.invalidate()
    }

    override fun onSensorChanged(olay: SensorEvent?) {
        if (olay == null || olay.sensor.type != Sensor.TYPE_ROTATION_VECTOR) return
        val deger = if (olay.values.size > 4) olay.values.copyOf(4) else olay.values
        val matris = FloatArray(9)
        val yonler = FloatArray(3)
        SensorManager.getRotationMatrixFromVector(matris, deger)
        SensorManager.getOrientation(matris, yonler)
        val manyetik = Math.toDegrees(yonler[0].toDouble())
        val gercek = Math.toRadians(manyetik + sapma)
        // Dairesel yumuşatma: titremeyi azaltır
        if (ilkOlcum) {
            sinOrt = Math.sin(gercek)
            cosOrt = Math.cos(gercek)
            ilkOlcum = false
        } else {
            sinOrt += 0.15 * (Math.sin(gercek) - sinOrt)
            cosOrt += 0.15 * (Math.cos(gercek) - cosOrt)
        }
        val derece = (Math.toDegrees(Math.atan2(sinOrt, cosOrt)) + 360.0) % 360.0
        pusula.yon = derece.toFloat()
        pusula.invalidate()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        kalibreYazi.text = if (accuracy <= SensorManager.SENSOR_STATUS_ACCURACY_LOW)
            "Pusula hassasiyeti düşük. Telefonu havada sekiz (8) çizer gibi hareket ettirerek kalibre et. Metal ve mıknatıstan uzak tut."
        else ""
    }

    // Sıradaki vakti bulur: (vakit no, zaman, yarın mı)
    private fun sonrakiBul(): Triple<Int, ZonedDateTime, Boolean>? {
        val ayar = getSharedPreferences("ayar", MODE_PRIVATE)
        val bolge = try {
            ZoneId.of(ayar.getString("bolge", "Europe/Istanbul") ?: "Europe/Istanbul")
        } catch (e: Exception) {
            ZoneId.of("Europe/Istanbul")
        }
        val simdi = ZonedDateTime.now(bolge)
        val bugun = simdi.toLocalDate()
        for (d in 0..1) {
            val gun = bugun.plusDays(d.toLong())
            val saatler = Vakitler.gunVerisi(this, gun) ?: continue
            for (j in 0..4) {
                val saat = saatler[besVakitAnahtar[j]] ?: continue
                val t = ZonedDateTime.of(gun, saat, bolge)
                if (t.isAfter(simdi)) return Triple(j, t, d == 1)
            }
        }
        return null
    }

    private fun sayimiGuncelle() {
        val sonraki = sonrakiBul()
        if (sonraki == null) {
            sonrakiYazi.text = "Vakitler alınıyor..."
            geriSayimYazi.text = "--:--:--"
            return
        }
        val (j, zaman, yarin) = sonraki
        val kalan = Duration.between(ZonedDateTime.now(zaman.zone), zaman)
        val sn = kalan.seconds.coerceAtLeast(0L)
        geriSayimYazi.text = String.format(Locale.US, "%02d:%02d:%02d", sn / 3600, (sn % 3600) / 60, sn % 60)
        sonrakiYazi.text = (if (yarin) "Yarın " else "") +
            "${Vakitler.adlar[j]} vaktine kalan süre (${zaman.toLocalTime().toString().take(5)})"
        if (besVakitSatir[j] != sonGosterilen) kartlariCiz()
    }

    private fun kartlariCiz() {
        vakitlerKutusu.removeAllViews()
        val saatler = Vakitler.gunVerisi(this, LocalDate.now())
        val sonraki = sonrakiBul()
        val vurgu = if (sonraki != null) besVakitSatir[sonraki.first] else -1
        for (i in 0..5) {
            val secili = i == vurgu
            val renk = if (secili) ZEMIN else if (i == 1) SOLUK else KREM

            val satir = LinearLayout(this)
            satir.orientation = LinearLayout.HORIZONTAL
            satir.gravity = Gravity.CENTER_VERTICAL
            satir.setPadding(dp(14), dp(12), dp(14), dp(12))
            if (secili) satir.background = arkaplan(ALTIN, 12)
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.setMargins(0, 0, 0, dp(4))
            satir.layoutParams = lp

            val ad = yazi(gorunenAd[i], 18f, renk, secili)
            ad.layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
            val saatMetni = saatler?.get(gorunenAnahtar[i])?.toString()?.take(5) ?: "--:--"
            val saat = yazi(saatMetni, 20f, renk, true)

            satir.addView(ad)
            satir.addView(saat)
            vakitlerKutusu.addView(satir)
        }
        sonGosterilen = vurgu
    }

    private fun kur() {
        val sehir = sehirKutusu.text.toString().trim().ifEmpty { "Bursa" }
        val kayma = (kaymaKutusu.text.toString().trim().toIntOrNull() ?: 0).coerceIn(-120, 120)
        getSharedPreferences("ayar", MODE_PRIVATE).edit()
            .putString("sehir", sehir)
            .putInt("kayma", kayma)
            .putBoolean("ezan", ezanKutusu.isChecked)
            .apply()
        sehirYazi.text = "${selam()} • $sehir"
        kaymaKutusu.setText(kayma.toString())
        durumYazi.text = "Vakitler alınıyor..."
        Thread {
            val mesaj = try {
                Vakitler.planla(applicationContext)
                "Alarmlar kuruldu." +
                    (if (kayma < 0) "\nBildirimler vakitten ${-kayma} dk önce gelir."
                    else if (kayma > 0) "\nBildirimler vakitten $kayma dk sonra gelir." else "")
            } catch (e: Exception) {
                "Hata: ${e.message}\nİnternet bağlantını ve şehir adını kontrol et."
            }
            runOnUiThread {
                durumYazi.text = mesaj
                konumuYukle()
                kartlariCiz()
                sayimiGuncelle()
            }
        }.start()
    }
}
